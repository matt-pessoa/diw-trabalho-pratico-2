# diw-trabalho-pratico-2
Trabalho Prático 2 - Portal de Filmes integrado com API

Link do Replit: https://replit.com/@MatheusPessoa4/MatheusPessoaTP2#

https://MatheusPessoaTP2.matheuspessoa4.repl.co
(No momento do envio do trabalho, por algum motivo não é possível acessar este link. Sugiro que entre no primeiro link para interagir com o site)

Repositório no GitHub: https://github.com/matt-pessoa/diw-trabalho-pratico-2